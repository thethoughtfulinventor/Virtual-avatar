class Brain:
    def __init__(self, llm_client):
        self.llm = llm_client

    def chat_loop(self):
        print("Aiya Engine Online")

        while True:
            user_input = input("You > ")

            if user_input.lower() in ["exit", "quit"]:
                break

            response = self.llm.generate(user_input)
            print(f"Aiya > {response}")
