from engine.brain import Brain
from llm.ollama_client import OllamaClient

def main():
    llm = OllamaClient()
    brain = Brain(llm)

    brain.chat_loop()

if __name__ == "__main__":
    main()
