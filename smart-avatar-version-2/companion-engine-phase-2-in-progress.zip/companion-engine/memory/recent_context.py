class RecentContext:

    def __init__(
        self,
        max_entries=50
    ):

        self.max_entries = max_entries

        self.entries = []

    def add(
        self,
        role,
        content
    ):

        self.entries.append(
            {
                "role": role,
                "content": content
            }
        )

        if len(
            self.entries
        ) > self.max_entries:

            self.entries.pop(0)

    def get_recent(
        self,
        count=10
    ):

        return self.entries[-count:]

    def clear(self):

        self.entries = []