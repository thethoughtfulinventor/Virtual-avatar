class Brain:

    def __init__(
        self,
        state_manager,
        event_bus,
        service_manager
    ):
        self.state = state_manager
        self.events = event_bus
        self.services = service_manager

        print("Brain initialized")
